import streamlit as st
st.title("🏋️ My Health Dashboard")
st.success("Wellness dashboard started.")